from django.contrib import admin
from .models import *
admin.site.register(Profile)
admin.site.register(Location)
admin.site.register(Phone)
admin.site.register(Gender)
admin.site.register(Post)
admin.site.register(Hashtag)
admin.site.register(Comment)
admin.site.register(FollowingFollower)
admin.site.register(Photo)
admin.site.register(Chat)
admin.site.register(ChatMember)
admin.site.register(Message)
